import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='danielba',
    application_name='improviser',
    app_uid='gWsW81j8Yj8LFkNtgJ',
    org_uid='1b6e8819-d8fe-4204-9567-dbd51f3bedc2',
    deployment_uid='8badb38f-c31d-4b77-a0c0-82ac0226e063',
    service_name='improviser',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.5.0',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'improviser-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
